// Fuel Express website interactions (JavaScript)
const fuelType = document.getElementById('fuelType');
const quantity = document.getElementById('quantity');
const total = document.getElementById('total');

function updateTotal() {
  const litres = Math.max(0, Number(quantity.value) || 0);
  const amount = litres * Number(fuelType.value);
  total.textContent = '₹' + amount.toLocaleString('en-IN', { maximumFractionDigits: 2 });
}
fuelType.addEventListener('change', updateTotal);
quantity.addEventListener('input', updateTotal);

const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');
menuToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  });
});

document.getElementById('interestForm').addEventListener('submit', event => {
  event.preventDefault();
  document.getElementById('formMessage').textContent =
    'Thank you! This demo form has not sent or saved your details.';
  event.target.reset();
});
